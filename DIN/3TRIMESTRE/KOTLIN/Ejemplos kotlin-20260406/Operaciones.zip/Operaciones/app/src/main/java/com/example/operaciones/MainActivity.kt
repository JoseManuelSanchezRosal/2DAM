package com.example.operaciones

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.operaciones.ui.theme.OperacionesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            OperacionesTheme {
                vistaOperaciones()
            }
        }
    }
}

@Composable
fun vistaOperaciones(){
    var numero1 by remember() { mutableStateOf("0") }
    var numero2 by remember() { mutableStateOf("0") }

    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Numero 1")
        //Extraer Variables
        OutlinedTextField(
            value = numero1,
            onValueChange = { newValue ->
                if(newValue.all{ it.isDigit()}){
                    numero1=newValue
                }
            }
        )
        Spacer(modifier = Modifier.padding(8.dp))

        Text("Numero 2")
        //Extraer Variables
        OutlinedTextField(
            value = numero2,
            onValueChange = { newValue ->
                if(newValue.all{ it.isDigit()}){
                    numero2=newValue
                }
            }
        )
        Spacer(modifier = Modifier.padding(15.dp))

        Text("El numero 1 vale: $numero1, y el numero 2 vale: $numero2")

    }

}

@Preview(showSystemUi = true)
@Composable
fun visualizar(){
    vistaOperaciones()
}
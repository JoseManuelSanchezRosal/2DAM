package com.example.cambiospantalla.vistas

import android.annotation.SuppressLint
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding

import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.cambiospantalla.Navegacion.vistasAplicacion



@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun primeraVentana(navController: NavController){
        Scaffold(topBar = {
            TopAppBar(title = { Text("Primera ventana") })
            }

        ) {
            cuerpoVista1(navController)
        }

}

@Composable
fun cuerpoVista1(navController: NavController){
    Column(modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
        horizontalAlignment = Alignment.CenterHorizontally
        ) {
        Text("Bienvenido a la vista nº 1")
        Button(onClick = {
            navController.navigate(route = vistasAplicacion.segundaVista.rutaV + "/Pedro")
        }) { Text("Cambiar vista") }
    }
}

/*
// Si queremos seguir viendo solo la preview creamos un controlador y listo
@Preview(showSystemUi = true)
@Composable
fun PreVisualizar(){
    primeraVentana()
}
*/
package com.example.cambiospantalla

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.cambiospantalla.Navegacion.navegacion
import com.example.cambiospantalla.ui.theme.CambiosPantallaTheme
import com.example.cambiospantalla.vistas.primeraVentana

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CambiosPantallaTheme {
                navegacion()
            }
        }
    }
}

/*
@Preview(showSystemUi = true)
@Composable
fun PreVisualizarPrincipal(){
    navegacion()
}
*/

@Preview(showSystemUi = true)
@Composable
fun previsualizar(){
    navegacion()
}
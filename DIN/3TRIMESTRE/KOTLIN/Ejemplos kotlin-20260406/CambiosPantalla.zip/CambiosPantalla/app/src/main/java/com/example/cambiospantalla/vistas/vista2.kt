package com.example.cambiospantalla.vistas

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.cambiospantalla.Navegacion.vistasAplicacion

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun segundaVentana(navController: NavController, texto: String?){
    Scaffold(topBar = {
        TopAppBar(title = { Text("Segunda ventana") },
            navigationIcon = {
                IconButton(onClick = {
                    navController.popBackStack()
                }) {
                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Hacia atras"
                    )
                }
            }
            )
    }) {
        cuerpoVista2(navController,texto)
    }

}

@Composable
fun cuerpoVista2(navController: NavController, texto: String?){
    Column(modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Biennnnnn")
        Text("Bienvenido a la vista nº 2")
        texto?.let {
            Text("Bienvenido $texto")
        }
        Button(onClick = {
            navController.navigate(route = vistasAplicacion.primeraVista.rutaV)
            //navController.popBackStack() // Esto es lo mismo que volver al estado anterior
        }) { Text("Cambiar vista") }
    }
}

/*
// Si queremos seguir viendo solo la preview creamos un controlador y listo
@Preview(showSystemUi = true)
@Composable
fun PreVisualizar2(){
    segundaVentana()
}
*/
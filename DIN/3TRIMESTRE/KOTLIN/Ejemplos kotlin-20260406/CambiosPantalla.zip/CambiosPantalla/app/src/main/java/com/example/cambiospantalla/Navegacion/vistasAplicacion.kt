package com.example.cambiospantalla.Navegacion

sealed class vistasAplicacion(val rutaV: String) {
    object primeraVista: vistasAplicacion("vistaUno")
    object segundaVista: vistasAplicacion("vistaDos")
}
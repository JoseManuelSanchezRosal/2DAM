package com.example.cambiospantalla.Navegacion

import androidx.compose.runtime.Composable
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.cambiospantalla.vistas.primeraVentana
import com.example.cambiospantalla.vistas.segundaVentana

@Composable
fun navegacion(){
    // Declaramos nuestro controlador de las vistas, esta variable tendra que pasarse entre pantallas
    val navController = rememberNavController()

    /* El navHost es lo que nos permitira movernos entre pantallas, le introducimos el controlador
    * que acabamos de crear y la clase que acabamos de crear y que contiene nuestras vistas
    *  */
    NavHost(navController = navController , startDestination = vistasAplicacion.primeraVista.rutaV) {
        composable(route =  vistasAplicacion.primeraVista.rutaV){
            primeraVentana(navController)
        }
        // Le estamos indicando que vamos a recibir un argumento precedido de /
        composable(route =  vistasAplicacion.segundaVista.rutaV + "/{text}", arguments = listOf(
            navArgument(name = "text"){
                type= NavType.StringType
            }
        )){
            segundaVentana(navController,it.arguments?.getString("text"))
        }
    }
}
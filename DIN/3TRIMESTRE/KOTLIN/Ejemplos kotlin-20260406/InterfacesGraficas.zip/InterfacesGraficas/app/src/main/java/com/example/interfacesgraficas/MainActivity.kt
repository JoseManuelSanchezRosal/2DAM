package com.example.interfacesgraficas

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {

    var num1: EditText? = null
    var num2: EditText? = null

    var resultado: TextView? = null
    var ejemplo2: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        // Aquí dentro realizamos los vínculos con los elementos gráficos
        num1=findViewById(R.id.numero1)
        num2=findViewById(R.id.numero2)

        resultado=findViewById(R.id.txtResultado)

        resultado?.text=""

        // Texto de ejemplo
        ejemplo2=findViewById(R.id.ejemploText)

    }

    //Creamos el evento
    /* Los eventos los creamos fuera de la creación de la instancia, pero dentro de la aplicación
     * Para definir una función evento tenemos que indicar que la función pertenece a la vista,
     * pasando por argumento view: View
     */
    fun cambiarTexto(view: View){
        ejemplo2?.text="El texto Cambio"
    }

    fun sumar(num1: Double, num2: Double): Double{
        var resultado: Double = num2 + num1
        return resultado
    }

    fun llamadaSuma(view: View){
        val numAux1=num1?.text.toString().toDouble()
        val numAux2=num2?.text.toString().toDouble()

        val resultadoNum=sumar(numAux2,numAux1)

        resultado?.text=resultadoNum.toString()

    }

}
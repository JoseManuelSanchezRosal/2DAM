package ComunicacionHilos;

public class Compartido {
    public int valor = 0;

    public int getValor() {
        return valor;
    }

    public void setValor(int valor) {
        this.valor = valor;
    }
}
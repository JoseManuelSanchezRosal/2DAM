package avanzadoMultiproceso.ProdConsBuffer;

//Crea un programa en Java que simule el problema Productor–Consumidor,
//pero con un buffer de tamaño limitado (por ejemplo, 3 posiciones): - El Productor debe ir generando números y guardarlos en el buffer. - El Consumidor debe ir sacando esos números del buffer y mostrándolos
//por pantalla. - Si el buffer está lleno, el Productor debe esperar hasta que el
//Consumidor libere espacio. - Si el buffer está vacío, el Consumidor debe esperar hasta que el
//Productor produzca algo. - Usa wait() y notifyAll() para coordinar la comunicación entre hilos.
//Inicialmente hacer el ejercicio con 1 productor y 1 consumidor.
//Posteriormente, ampliar a 2 y 2.
public class Comunicacion {
}
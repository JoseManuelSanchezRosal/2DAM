package avanzadoMultiproceso.ProdConsBuffer;

public class Consumidor {
}

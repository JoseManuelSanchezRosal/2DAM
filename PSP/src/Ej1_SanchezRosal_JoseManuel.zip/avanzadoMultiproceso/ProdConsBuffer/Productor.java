package avanzadoMultiproceso.ProdConsBuffer;

public class Productor {
}

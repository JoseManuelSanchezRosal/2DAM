const $form = document.querySelector('form');
const $resultados = document.getElementById('resultados');

let formulario = {
    titulo: '',
    cuerpo: '',
    autor: ''
}

$form.addEventListener('submit', e => {
    e.preventDefault();
    
    const formData = new FormData($form);
    const data = Object.fromEntries(formData.entries());
    formulario = {
        ...data
    }
    $form.reset();

    const p = document.createElement('p');
    p.textContent = JSON.stringify(formulario);
    $resultados.appendChild(p);
});
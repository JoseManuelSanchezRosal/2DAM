function calcular(operacion) {
    const operaciones = {
        '+': (num1, num2) => num1 + num2,
        '-': (num1, num2) => num1 - num2,
        'x': (num1, num2) => num1 * num2,
        '/': (num1, num2) => num1 / num2
    }

    for (const signo of Object.keys(operaciones)) {
        if (operacion.includes(signo)) {
            const [num1, num2] = operacion.split(signo);
            return operaciones[signo](parseInt(num1), parseInt(num2));
        }
    }
}
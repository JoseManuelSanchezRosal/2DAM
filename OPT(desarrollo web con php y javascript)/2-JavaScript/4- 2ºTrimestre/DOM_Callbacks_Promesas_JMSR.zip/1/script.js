const $tareas = document.getElementById('tareas');
const $inputTarea = document.getElementById('input-tarea');
const $aniadirTarea = document.getElementById('aniadir-tarea');
const $editarTarea = document.getElementById('editar-tarea');
let selectedValue;

$aniadirTarea.addEventListener('click', () => {
    const { value } = $inputTarea;
    if (!value.trim()) {
        alert('La tarea está vacía');
        $inputTarea.value = '';
        return;
    }

    const lis = document.querySelectorAll('#tareas li');
    for (const li of lis) {
        if (li.querySelector('span').textContent === value) {
            alert('Esta tarea ya existe en la lista');
            $inputTarea.value = '';
            return;
        }
    }
    
    const li = document.createElement('li');
    const span = document.createElement('span');
    const buttonDelete = document.createElement('button');

    li.classList.add('tarea-row');
    span.textContent = value;
    span.addEventListener('click', ({ target }) => {
        const { textContent } = target;
        $inputTarea.value = textContent;
        selectedValue = textContent;
    });
    buttonDelete.addEventListener('click', () => {
        li.remove();
    });
    buttonDelete.textContent = 'X';

    li.appendChild(span);
    li.appendChild(buttonDelete);
    $tareas.appendChild(li);
    $inputTarea.value = '';
});

$editarTarea.addEventListener('click', () => {
    const { value } = $inputTarea;
    if (!value.trim()) {
        alert('La tarea está vacía');
        $inputTarea.value = '';
        return;
    }

    const lis = document.querySelectorAll('#tareas li');
    for (const li of lis) {
        const span = li.querySelector('span');
        if (span.textContent === selectedValue) {
            span.textContent = value;
        }
    }
    $inputTarea.value = '';
});
const $eliminarProducto = document.getElementById('eliminar-producto');
const $modal = document.querySelector('.modal');
const $modalContent = document.querySelector('.modal-content');
const $confirmar = document.getElementById('confirmar');
const $cancelar = document.getElementById('cancelar');

$eliminarProducto.addEventListener('click', async () => {
    document.body.classList.add('show');

    const quiereBorrar = await new Promise(resolve => {
        $confirmar.addEventListener('click', () => {
            resolve(true);
        });

        $cancelar.addEventListener('click', () => {
            resolve(false);
        });
    });

    if (!quiereBorrar) {
        document.body.classList.remove('show');
        return;
    }
    
    console.log('Producto eliminado')
    document.body.classList.remove('show');
});

$modal.addEventListener('click', () => {
    document.body.classList.remove('show');
});

$modalContent.addEventListener('click', e => {
    e.stopPropagation();
})
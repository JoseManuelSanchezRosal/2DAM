const $input = document.getElementById('input');
const $resultado = document.getElementById('resultado');

$input.addEventListener('input', ({ target }) => {
    $resultado.textContent = funcion(target.value, text => {
        if (/^[0-9]{1,}$/.test(text)) {
            return 'Es numérico';
        } else if (/[a-zA-Z0-9]{1,}/.test(text) && /[0-9]{1,}/.test(text)) {
            return 'Es alfanumérico';
        } else {
            return 'Es alfabético';
        }
    });
});

function funcion(texto, callback) {
    return callback(texto);
}
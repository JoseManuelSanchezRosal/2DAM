function mensaje() {
    console.log('Iniciando función');
    new Promise(resolve => {
        console.log('Estoy dentro de la promesa');
        setTimeout(() => {
            console.log('Salí de la promesa')
            resolve();
        }, 3000);
    });
}

mensaje();
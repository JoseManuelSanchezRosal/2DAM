const productos = [
    {
        id: 1,
        name: 'Ordenador sobremesa',
        price: 584.3,
        stock: 5
    },
    {
        id: 2,
        name: 'Móvil',
        price: 43.3,
        stock: 510
    },
    {
        id: 3,
        name: 'Reloj Suunto',
        price: 432.5,
        stock: 2
    }
];

function obtenerProducto(id) {
    return new Promise((resolve, reject) => {
        const producto = productos.find(producto => producto.id === id);
        if (producto) {
            resolve(producto);
        } else {
            reject(new Error('No se ha encontrado el producto'));
        }
    });
}

obtenerProducto(10)
    .then(producto => {
        console.log(producto)
    })
    .catch(error => {
        console.error(error);
    });
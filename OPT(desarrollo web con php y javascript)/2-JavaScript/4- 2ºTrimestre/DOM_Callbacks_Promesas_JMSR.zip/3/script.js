const $contenido = document.getElementById('contenido');
const $datos = document.getElementById('datos');
const $generar = document.getElementById('generar');

$generar.addEventListener('click', () => {
    const { value } = $datos;
    if (!value.trim()) {
        return;
    }

    dibujar(value);
    $datos.value = '';
});

function dibujar(texto) {
    const elementos = texto.split(' ');

    const tr = document.createElement('tr');
    for (const elemento of elementos) {
        const td = document.createElement('td');
        if (!isNaN(elemento)) {
            td.classList.add('number');
        } else if (['true', 'false'].includes(elemento)) {
            td.classList.add('bool');
        } else {
            td.classList.add('string');
        }
        td.textContent = elemento;
        tr.appendChild(td);
    }
    $contenido.appendChild(tr);
}
async function saludar(nombre, apellido) {
    const nombre1 = await new Promise(resolve => {
        resolve(prompt('Introduce tu nombre'));
    });

    const apellidos1 = await new Promise(resolve => {
        resolve(prompt('Introduce tu apellido'));
    });

    console.log(`Hola ${nombre1} ${apellidos1}`)
}
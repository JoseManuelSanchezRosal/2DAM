function saludar(nombre) {
    new Promise(resolve => {
        setTimeout(() => {
            console.log(`Hola ${nombre}`);
            resolve();
        }, 2000);
    });
}

saludar('José');
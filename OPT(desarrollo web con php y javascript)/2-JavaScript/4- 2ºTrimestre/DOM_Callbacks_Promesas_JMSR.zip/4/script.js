const $num1 = document.getElementById('num1');
const $num2 = document.getElementById('num2');
const $operacion = document.getElementById('operacion');
const $calcular = document.getElementById('calcular');
const $resultados = document.getElementById('resultados');

const operaciones = {
    suma: (num1, num2) => num1 + num2,
    resta: (num1, num2) => num1 - num2,
    producto: (num1, num2) => num1 * num2,
    division: (num1, num2) => num1 / num2
}

$calcular.addEventListener('click', () => {
    const { value: value1 } = $num1;
    const { value: value2 } = $num2;
    if (!value1.trim() || !value2.trim()) {
        return;
    }

    const operacion = operaciones[$operacion.value];
    
    const tr = document.createElement('tr');
    const num1Td = document.createElement('td');
    const num2Td = document.createElement('td');
    const operacionTd = document.createElement('td');
    const resultadoTd = document.createElement('td');

    num1Td.textContent = value1;
    num2Td.textContent = value2;
    operacionTd.textContent = $operacion.value;
    resultadoTd.textContent = operacion(parseInt(value1), parseInt(value2));

    tr.appendChild(num1Td);
    tr.appendChild(num2Td);
    tr.appendChild(operacionTd);
    tr.appendChild(resultadoTd);
    $resultados.appendChild(tr);

    $num1.value = '';
    $num2.value = '';
    $operacion.value = 'suma';
});
var var1, var2=null;

function sumar(x, y){
    var resultado = x + y;
    document.getElementById('demo').innerHTML="El resultado es: " + resultado + " del tipo: " + typeof(resultado);
}
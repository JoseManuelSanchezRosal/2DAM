function cambTexto(){
    let cadena1;
    cadena1=document.getElementById("entrada1").value;

    document.getElementById('demo').innerHTML=cadena1;

}
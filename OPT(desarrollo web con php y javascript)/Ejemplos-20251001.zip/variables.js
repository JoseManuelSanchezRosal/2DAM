var nombre = "Pedro Garcia";
var num1 = 198;
var num2 = 3.14159265;
var VeroFal = true;

function variable1(){
    document.getElementById('mielemento').innerHTML=nombre;
}

function variable2(){
    document.getElementById('mielemento').innerHTML=num1;
}

function variable3(){
    document.getElementById('mielemento').innerHTML=num2;
}

function variable4(){
    document.getElementById('mielemento').innerHTML=VeroFal;
}
function introducirElem(){
    document.getElementById("elejs").innerHTML="<p>Elemento introducido por JavaScript</p>";
}
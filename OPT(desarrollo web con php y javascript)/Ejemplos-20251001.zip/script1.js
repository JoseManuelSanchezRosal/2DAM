var pasadas = 0;
    
function anunciarPasadas() {
    pasadas = pasadas + 1;
    alert('Has pasado el ratón encima ' + pasadas + ' veces');
} 